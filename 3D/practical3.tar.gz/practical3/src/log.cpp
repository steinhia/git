/*  Created on: Dec 13, 2015
 *      Author: T. Delame (tdelame@gmail.com)
 */
# include "./../include/log.hpp"
const std::string severity_names[6] = {
    "[ trace ]",
    "[ debug ]",
    "[ info  ]",
    "[warning]",
    "[ error ]",
    "[ fatal ]"
};
